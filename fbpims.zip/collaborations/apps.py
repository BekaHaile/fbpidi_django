from django.apps import AppConfig


class CollaborationsConfig(AppConfig):
    name = 'collaborations'
