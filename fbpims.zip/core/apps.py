from django.apps import AppConfig


class AdminSiteConfig(AppConfig):
    name = 'core'
